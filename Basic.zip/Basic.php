<!DOCTYPE html>
<html>
  <head>
    <?php 
      include 'connect.php';
      $sql = mysql_query("SELECT * FROM display ORDER BY Rand()");
      $row = mysql_fetch_array($sql);
   
    ?>
    <meta name="viewport" content="width=device-width, initial-scale=1.0 user-scalable=no">
    <meta name="description" content="dzingo! is a platform created to bring friends and families even closer. Join dzingo! today to become a part of a wonderful family.">

    <meta name="author" content="#TheZheenoFoundation">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
    <!-- Loading Bootstrap -->
    <link href="dist/css/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="dist/css/ziingo_styles.css" rel="stylesheet">    
    <!-- Loading Flat UI -->
    <link href="dist/css/flat-ui.css" rel="stylesheet">
    <link href="docs/assets/css/demo.css" rel="stylesheet">

    <link rel="shortcut icon" href="images/favicon.png" type="image/png" >
          </head>
    <title>dzingo! - Social networking with a difference</title>
  </head>
  <body style="background-color:#272727;color:#FFF">
    <center><h6 style="font-size:30px" OnClick='window.self.location="Basic.php"'>Zinger Basic</h6>

      <!-- sign in form -->
      <?php if (!isset($_GET['SignUp'])): ?>
        <form method="POST" action="security.php">
          <h6>Sign In</h6>
          <input name="HexCode" type="hidden" value="<?php echo $row['HexCode']; ?>">
          <input id='email' placeholder="Handle" class="form-control flat" name='email' type="text" style="border-radius:0px;height:40px;width:85%;margin-top:10px;" required>
          <input id='password' placeholder="Password" class="form-control flat" name='pass' type="password" style="border-radius:0px;height:40px;width:85%;" required>
          <button type="submit" name="submit" OnClick='InitiateLogin();$("#SignInDiv").collapse("hide");window.self.location="#top";' class="btn-block btn-primary" style="height:40px;width:85%;">Sign In</button><br>
          <div style="text-align:center;width:85%;font-size:15px">Join the fun train now... you don't wanna be left out.</div>
          <button type="button" OnClick='window.self.location="Basic.php?SignUp"' class="btn-block btn-primary" data-toggle="collapse" style="height:40px;width:85%;border-radius:20px;">Sign Up</button><br>                              
          <span style="font-size:15px"> Switch to <a href="index.php">Classic version</a> for compatible browsers</span>
        </form>
      <?php endif ?>
      <!-- sign in form ends -->

      <!-- sign up form -->
      <?php if (isset($_GET['SignUp'])): ?>
          <form id='@signup_form' style="display:block" method="POST" action="signup_handler.php">
        <input type="text" id="nick" placeholder="Handle e.g Jamie"  name="nick" class="form-control flat" style="border-radius:0px;height:40px;width:85%;" autocomplete="off" required/>
          <i id="nick0" style="color:#E74C3C;display:none;margin-top:-30px;margin-right:5px" class="pull-right fui-cross-circle"></i>
          <i id="nick1" style="color:#2ECC71;display:none;margin-top:-30px;margin-right:5px" class="pull-right fui-check-circle"></i>
       <input type="email" OnBlur="validate_email(email,'invalid mail');validate_form('signup_form')" value="" placeholder="E-mail" id="Semail" name="email"  class="form-control flat" style="border-radius:0px;height:40px;width:85%;" autocomplete="off" required/>
           <i id="email0" style="color:#E74C3C;display:none;margin-top:-30px;margin-right:5px" class="pull-right fui-cross-circle"></i>
          <i id="email1" style="color:#2ECC71;display:none;margin-top:-30px;margin-right:5px" class="pull-right fui-check-circle"></i>
        <select class="form-control flat" style="border-radius:0px;height:40px;width:85%;" id="sex" name="sex"  required/>
          <optgroup label="Sex">
            <option value="MALE">Male</option>
            <option value="FEMALE">Female</option>
          </optgroup>
        </select>
        <tr><td><input OnBlur="validate_email(Semail,'invalid mail');PassMatch();"  type="password"  placeholder="Password" id="pass" name="pass"  class="form-control flat" style="border-radius:0px;height:40px;width:85%;" autocomplete="off" required/>
        <i id="pass0" style="color:#E74C3C;display:none;margin-top:-30px;margin-right:5px" class="pull-right fui-cross-circle"></i>
        <i id="pass0_ok" style="color:#2ECC71;display:none;margin-top:-30px;margin-right:5px" class="pull-right fui-check-circle"></i>
        <input OnBlur="validate_email(Semail,'invalid mail');PassMatch();" type="password"  placeholder="Re-type Password" id="pass2" name="pass2"  class="form-control flat" style="border-radius:0px;height:40px;width:85%;" autocomplete="off" required/>
        <i id="pass_2_0" style="color:#E74C3C;display:none;margin-top:-30px;margin-right:5px" class="pull-right fui-cross-circle"></i>
        <i id="pass_2_0_ok" style="color:#2ECC71;display:none;margin-top:-30px;margin-right:5px" class="pull-right fui-check-circle"></i>
        <small id="ErrorDiv" style="color:#FFF;display:none">User exist</small>
          <button type="submit" name="SignUp" class="btn-block btn-info" style="height:40px;width:85%;">Sign Up</button>
        <p>&nbsp;</p>
        <span style="font-size:15px">Don't miss out on the fun</span>
        <button type="button" OnClick='window.self.location="Basic.php"' class="btn-block btn-primary" data-toggle="collapse" style="height:40px;width:85%;border-radius:20px;">Sign In</button>
        <span style="font-size:15px"> Switch to <a href="index.php">Classic version</a> for compatible browsers</span>
    </form>
    <?php endif ?>
    <!-- sign up form ends-->
    </center>
  </body>
  </html>

    <script src="dist/js/vendor/jquery.min.js"></script>
    <script src="dist/js/vendor/video.js"></script>
    <script src="dist/js/flat-ui.min.js"></script>

    <script src="docs/assets/js/AjaxZing.js"></script>
    <script src="docs/assets/js/prettify.js"></script>
    <script src="docs/assets/js/application.js"></script>