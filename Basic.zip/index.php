<!DOCTYPE html>
<html>
  <head>
   <meta name="viewport" content="width=device-width, initial-scale=1.0 user-scalable=no">
      <meta name="description" content="dzingo! is a platform created to bring friends and families even closer. Join dzingo! today to become a part of a wonderful family.">

      <meta name="author" content="#TheZheenoFoundation">
     <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
  <!-- Loading Bootstrap -->
      <link href="dist/css/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
      <link href="dist/css/ziingo_styles.css" rel="stylesheet">    
      <!-- Loading Flat UI -->
      <link href="dist/css/flat-ui.css" rel="stylesheet">
      <link href="docs/assets/css/demo.css" rel="stylesheet">

      <link rel="shortcut icon" href="images/favicon.png" type="image/png" >
      <script type="application/ld+json">
{
  "@context" : "http://schema.org",
  "@type" : "Social Network",
  "name" : "Dzingo!",
  "url" : "https://www.dzingoonline.com",
  "sameAs" : [
    "https://twitter.com/dzingoonline",
    "https://plus.google.com/+dzingoonline",
    "https://www.facebook.com/dzingoonline",
 ]
}
</script>
      <script type="text/javascript">
      //document.getElementById("ButtonDisabled").disabled = true;
      //Login to MembersArea 

    var XMLHttpRequestObject = false;
  if (window.XMLHttpRequest) {
  XMLHttpRequestObject = new XMLHttpRequest();
  } else if (window.ActiveXObject) {
  XMLHttpRequestObject = new ActiveXObject("Microsoft.XMLHTTP");
  }
    function LoginMain()
  {
  if(XMLHttpRequestObject) {
  var obj = document.getElementById("ErrorDiv");
  var email = document.getElementById('email').value;
  var password = document.getElementById('password').value;
  document.getElementById('holder').style.display='block';
  XMLHttpRequestObject.open("GET", "security.php?email="+email+"&pass="+password+"&submit");
  XMLHttpRequestObject.onreadystatechange = function()
  {
  if (XMLHttpRequestObject.readyState == 4 && XMLHttpRequestObject.status == 200) {
  obj.innerHTML = XMLHttpRequestObject.responseText;
  }
  }
  XMLHttpRequestObject.send(null);
  }

  return(1);

  }
  function Cancel(){
    window.stop();
    document.getElementById('holder').style.display='none';
  }
  function InitiateLogin(){
    document.getElementById('SignInDiv').style.display = "none";
    document.getElementById('SignInProgressDiv').style.display = "block";
    setTimeout('$("#Smooth").collapse("show");',1000);
    setTimeout('document.getElementById("notifier").style.display = "block";',2000);
    var email = document.getElementById('email').value;
    var pass = document.getElementById('password').value;
    var HexCode = document.getElementById('HexCode').value;
    var obj = document.getElementById("notifier");
  }
  </script>
    <?php  include ("connect.php"); 
    #include ("security.php");
     include ("recovery.php");
       //Checks if there is a login cookie
 if(isset($_COOKIE['ID_my_site']))


 //if there is, it logs you in and directes you to the members page
 {
    $username = $_COOKIE['ID_my_site'];

    $pass = $_COOKIE['Key_my_site'];

        $check = mysql_query("SELECT * FROM users WHERE username = '$username' || nick = '$username'  ")or die(mysql_error());

        while($info = mysql_fetch_array( $check ))
        {

          if ($pass != $info['password'])

              {
                //do nothing
              }

          else
              {
              mysql_query("UPDATE users SET status='Online' WHERE username='$username' || nick = '$username' "); ?>
              <script type="text/javascript">
                window.location = "indexA.php?Async=true&Codec=100";
              </script>
              <?php 
              #header("Location: indexA.php?Async=true&Codec=100");

            }

        }

 }


 //if the login form is submitted
    $sql = mysql_query("SELECT * FROM display ORDER BY Rand()");
    $row = mysql_fetch_array($sql);
    if (isset($_GET['activate'])) {
      $id = $_GET['id'];
      $key = $_GET['key'];
      mysql_query("UPDATE account_list SET status = 'ACTIVATED' WHERE user_id ='$id' AND code = '$key' ");
    }
    ?> 
      </head>
      <title>dzingo! - Social networking with a difference</title>
  </head>
  <body style="background-color:#272727">
  <script>
  window.fbAsyncInit = function() {
    FB.init({
      appId      : '904693392917307',
      xfbml      : true,
      version    : 'v2.5'
    });
  };

  (function(d, s, id){
     var js, fjs = d.getElementsByTagName(s)[0];
     if (d.getElementById(id)) {return;}
     js = d.createElement(s); js.id = id;
     js.src = "//connect.facebook.net/en_US/sdk.js";
     fjs.parentNode.insertBefore(js, fjs);
   }(document, 'script', 'facebook-jssdk'));

function switcher(){
    $('#myCarousel').carousel({
        //interval: 2000;
    })
}
  setTimeout('switcher();',3000);

</script>
    <div id="PageContainer" style="height:100%;width:100%">
      <div id="top"></div>
        <div style="background:transparent;height:100%;width:100%;margin-left:0px;margin-top:0px;color:#FFF;">  
          <center>
            
            <img OnClick="self.location='index.php'" alt="dzingo logo" src="images/zinger(2).jpg" style="width:140px;top:10px;position:relative">
              <div  id="myCarousel" class="collapse in carousel slide" style="width:100%;height:80%;margin-top:5px">
                <!-- Carousel items -->
                <div class="carousel-inner" style="height:100%;color:#FFF">
                  <div class="item active" style="height:280px;background:transparent">
                  <div class="carousel-caption" style="top:-20px;position:absolute">
                      <p>Find people near you</p>
                    </div>
                    <button type="button" class="btn btn-danger active fui-location" style="background:transparent;color:#C0392B;height:70px;width:70px;border:0px;border-radius:70px;font-size:50px;right:-80px;top:30px;position:relative;z-index:1"></button>
                    
                      <!--<img src="images/fome_crop.png" class="img-polaroid" width="130px" style="position:relative;transform:rotate(-20deg);left:-130px;top:60px;">
                      <img src="images/zino_crop.png" class="img-polaroid" width="130px" style="position:relative;transform:rotate(20deg);right:-130px;top:-70px;">
                      --><img src="images/annie_crop (2).png" class="img-circle" width="230px" style="position:relative;top:-30px;">
                  </div>
                  <div class="item" style="height:280px;background:transparent">
                  <div class="carousel-caption" style="top:-20px;position:absolute">
                      <p>Socialize</p>
                    </div>
                    <button type="button" class="btn btn-success" style="top:120px;right:-120px;position:relative">mingle</button>
                    <img src="images/sophia.jpg" class="img-circle" width="230px">
                    <button type="button" class="btn btn-info" style="top:-80px;left:-70px;position:relative">share</button>
                    <button type="button" class="btn btn-primary" style="top:-180px;left:-160px;position:relative">chat</button>
                  </div>
                  <div class="item" style="height:280px;background:transparent">
                    <div class="carousel-caption" style="top:-20px;position:absolute">
                      <p>Make new friends</p>
                    </div>
                    <button type="button" class="btn btn-danger active fui-heart" style="height:70px;width:70px;border:0px;border-radius:70px;font-size:40px;right:0px;top:100px;position:relative;z-index:1"></button>
                      <img src="images/sophia2.jpg" class="img-circle" width="180px" style="transform:rotate(20deg);position:relative;left:-100px;top:-30px;">
                      <img src="images/ofeg_full.jpeg" class="img-circle" width="180px" style="position:relative;right:-100px;top:-208px;">
                    </div>
                </div>
                  <a class="carousel-control left" href="#myCarousel" data-slide="prev" style="background:transparent;font-size:20px">&nbsp;</a>
                  <a class="carousel-control right" href="#myCarousel" data-slide="next" style="background:transparent;font-size:20px">&nbsp;</a>
                  <div style="bottom:5px;position:fixed;width:100%;text-align:center;font-size:14px;z-index:3">
                  <button type="button" OnClick='$("#SignInDiv").collapse("show");$("#myCarousel").collapse("hide");window.self.location="#top";' class="btn-block btn-primary" data-toggle="collapse" style="height:40px;width:85%;border-radius:20px;left:7.5%;bottom:30px;position:fixed">Sign In</button><br>                              
                  <span class="hidden">Not a member? <a OnClick='$("#SignUpDiv").collapse("show");$("#myCarousel").collapse("hide");window.self.location="#top";'>Create an account.</a></span><br>
                  <span style="font-size:15px"> Switch to <a href="Basic.php">Basic version</a> for older browsers</span>
                  </div>
              </div>


            <div id="SignInProgressDiv" class="collapse">
              <h6>Sign In</h6>
              
              <div id="Smooth" class="collapse"><p>&nbsp;</p></div>
              <div  style="width:85%;height:120px;background-color:#FFF;">
                <center>
                  <br>
                  <button id="holder" style="display:block;height:40px;width:40px;background-color:#D7D7D7;border:0px solid #CCC;border-radius:5px;opacity:0.6">
                    <img src="images/bars.gif"  style="width:20px;">
                  </button>
                  <span id="notifier" style="color:#010101;display:none">Signing in...</span>
                </center>
              </div><p>&nbsp;</p>
            </div>
              <div id="SignInDiv" class="collapse">
                <form method="POST" action="security.php">
                  <h6>Sign In</h6>
                  <input name="HexCode" type="hidden" value="<?php echo $row['HexCode']; ?>">
                  <input id='email' placeholder="Handle" class="form-control flat" name='email' type="text" style="border-radius:0px;height:40px;width:85%;margin-top:10px;" required>
                  <input id='password' placeholder="Password" class="form-control flat" name='pass' type="password" style="border-radius:0px;height:40px;width:85%;" required>
                  <button type="submit" name="submit" OnClick='InitiateLogin();$("#SignInDiv").collapse("hide");window.self.location="#top";' class="btn-block btn-primary" style="height:40px;width:85%;">Sign In</button><br>
                  <div style="text-align:center;width:85%;font-size:15px">Join the fun train now... you don't wanna be left out.</div>
                  <button type="button" OnClick='$("#SignUpDiv").collapse("show");$("#SignInDiv").collapse("hide");window.self.location="#top";' class="btn-block btn-primary" data-toggle="collapse" style="height:40px;width:85%;border-radius:20px;">Sign Up</button><br>                              
                </form>
                <div id="ErrorDiv" style="color:#FFF;display:none"></div>
                  <span style="font-size:15px">Forgot your login details? <b  data-toggle="collapse" data-target="#recovery">Get help signing in.</b></span>
                  <div id="recovery" class="collapse">
                    <!--<div class="user-pic">
                      <span class="fui-user" style="margin-left:5px"></span>
                    </div>-->
                    <small class="pull-left" style="margin-left:10%">Recover your password</small><br>
                  </div>
              </div>
              <div id="SignUpDiv" class="collapse">
                  <h6>Sign Up</h6>
                  <?php include 'signup.php'; ?>
              </div>
            </center>
            </div>

           <div class="fb-like" data-href="http://www.dzingoonline.com/index.php" data-width="50" data-layout="box_count" data-action="like" data-show-faces="true" data-share="true"></div>

        </div>
  </body>
</html>

    <script src="dist/js/vendor/jquery.min.js"></script>
    <script src="dist/js/vendor/video.js"></script>
    <script src="dist/js/flat-ui.min.js"></script>

    <script src="docs/assets/js/AjaxZing.js"></script>
    <script src="docs/assets/js/prettify.js"></script>
    <script src="docs/assets/js/application.js"></script>

    <script>
      videojs.options.flash.swf = "dist/js/vendor/video-js.swf"
    </script>