    <?php
     //This code runs if the form has been submitted
include 'connect.php';

if (isset($_POST['SignUpComplete'])) {
  $email=$_POST['EmailHolder'];
  $fname=$_POST['fname'];
  $phone=$_POST['phone'];
  $loc=$_POST['loc'];
  mysql_query("UPDATE users SET fullname = '$fname', phoneno = '$phone', location = '$loc' WHERE username = '$email' ");
  #redirect user to main page
  header("Location:indexA.php?Async=true&Codec=100");
}

 if (isset($_POST['SignUp'])) { 
  $status = "Injected";
 // checks if the username is in use
 	if (!get_magic_quotes_gpc()) {
 		$_POST['email'] = addslashes($_POST['email']);
    $_POST['nick'] = addslashes($_POST['nick']);
 	}
 $usercheck = $_POST['email'];
 $handle = handle($_POST['nick']);
 $PassRed = $_POST['pass'];
 $userCHK = mysql_query("SELECT * FROM users WHERE username = '$usercheck' OR email = '$usercheck' OR nick = '$handle' ");
 $userCount = mysql_num_rows($userCHK);

  if($userCount == NULL){

    if ($status == "Injected") {
          // here we encrypt the password and add slashes if needed
          $_POST['pass'] = md5($_POST['pass']);
          $_POST['pass2'] = md5($_POST['pass2']);
          if (!get_magic_quotes_gpc()) {
            $_POST['pass'] = addslashes($_POST['pass']);
            $_POST['nick'] = addslashes($handle);
            $_POST['email'] = addslashes($_POST['email']);
          }

          //here we check for password match and other variables
          if($_POST['pass'] == $_POST['pass2']){
          // now we insert it into the database
            $password=$_POST['pass'];
            $email=$_POST['email'];
            $date = date("D M d, Y");
            $nick = $handle;
            $sex = $_POST['sex'];
             mysql_query("INSERT INTO users (username,email,password,nick,sex,date_joined) VALUES ('$email','$email','$password','$nick','$sex','$date')"); 
             $sql=mysql_query("SELECT * FROM users WHERE username = '$email' ");
             $row=mysql_fetch_array($sql);
             $idn2p=$row['id'];
    
            $validCharacters = "ABCDEFGHIJKLMNOPQRSTUXYVWZ1234567890";
            $validCharNumber = strlen($validCharacters);
            $result = "";
            $length = 20;
            for ($i = 0; $i < $length; $i++) {
                $index = mt_rand(0, $validCharNumber - 1);
                $result .= $validCharacters[$index];
              }
           mysql_query("INSERT INTO account_list (user_id,code,status) VALUES ('$idn2p','$result','NOT ACTIVATED') ");
    
            //initialize cookie values
            $_POST['email'] = $email;
            $_POST['email'] = stripslashes($_POST['email']);
            $hour = time() + 604800;//one week
            setcookie("ID_my_site", $_POST['email'], $hour);
            setcookie("Key_my_site", $_POST['pass'], $hour);
            $HexCode = "#34495E";
            mysql_query("UPDATE users SET status = 'Online', HexCode = '$HexCode' WHERE id = '$idn2p' ");
        

            //initialize file folders for user files
             if (!file_exists("Users/$email")) {
              mkdir("Users/$email");
              mkdir("Users/$email/Photos");
              mkdir("Users/$email/Photos/ProfilePic");

              //sends notification to user's email
              $to = $email;
              $subject="Welcome to Zinger!";
              $message="Welcome to Zinger!. You have successfully been registered on Zinger!.\n
                        ---Your details are as follows---
                        Login ID: $email 
                        Handle: $handle 
                        Password: $PassRed
                        This message was intended for ".$email." Please ignore if you are not the individual in question.thank you.
                        Follow click the link below to login
                        http://www.dzing.netau.net/accounts.php?id=$idn2p&key=$result&activate";
              $from="#TheZheenoFoundation!";
              $headers="From: $from";
              mail($to,$subject,$message,$headers);
            }
          }#endif for variable check
       }
       #if sign up is successful
      $status = 1;
    }
    else{
      #if sign up failed
      $status = 0;
    } ?>
<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1.0 user-scalable=no">
  <meta name="description" content="dzingo! is a platform created to bring friends and families even closer. Join dzingo! today to become a part of a wonderful family.">
  <meta name="author" content="#TheZheenoFoundation">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
  <!-- Loading Bootstrap -->
  <link href="dist/css/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="dist/css/ziingo_styles.css" rel="stylesheet">    
  <!-- Loading Flat UI -->
  <link href="dist/css/flat-ui.css" rel="stylesheet">
  <link href="docs/assets/css/demo.css" rel="stylesheet">
  <link rel="shortcut icon" href="images/favicon.png" type="image/png" >
  <title>Sign Up</title>
</head>
<body style="background-color:#272727;color:#FFF">
  <center>
  <img OnClick="self.location='index.php'" alt="dzingo logo" src="images/zinger(2).jpg" style="width:140px;top:10px;position:relative">
  <h6>Sign Up</h6>
<?php if($status == 1): ?>
    <div style="text-align:center;background-color:#ECF0F1;color:#34495E" id="ColYes" class="collapse in">
      <div class="alert alert-success" style="border-radius:0px">
        <span class="fui-check-circle"></span>&nbsp;
        Account created.<br>Please check your mailbox for an activation link to activate your account. Thank you.
      </div>
      <form method="POST" action="<?php $_SERVER['PHP_SELF'] ?>">
      <input type="hidden" name="EmailHolder" value="<?php echo $_POST['email'] ?>">
      <h6>Create a profile</h6>
      <div class="btn-block carousel slide" id="PSet">
        <!-- Carousel items -->
        <div class="carousel-inner">
          <div class="item active">
            <p>Tell us about yourself</p>
            <small>We want to know you <span style="font-size:30px;color:#E74C3C">:)</span></small>
            <input name='fname' placeholder="Full name" class="form-input-text form-control flat" style="border-radius:0px" name='fname' type="text" required/>
             <button type="button" class="pull-left btn-inverse" style="height:40px;font-size:20px" OnClick="self.location='indexA.php?Async=true&Codec=100'">
              &nbsp;Skip >>&nbsp;
            </button>
            <button class="pull-right btn-primary" style="height:40px;width:80px;font-size:25px" href="#PSet" data-slide="next">
              <span class="fui-arrow-right"></span>
            </button>
          </div>
          <div class="item">
            <p>Almost there!</p>
            <small>Let's communicate <span style="font-size:30px;color:#E67E22">:)</span></small>
            <input name='phone' placeholder="Phone no." class="form-input-text form-control flat" style="border-radius:0px" name='phone' type="text" required/>
            <button class="pull-left btn-inverse" style="height:40px;width:80px;font-size:25px" href="#PSet" data-slide="prev">
              <span class="fui-arrow-left"></span>
            </button>
            <button class="pull-right btn-primary" style="height:40px;width:80px;font-size:25px" href="#PSet" data-slide="next">
              <span class="fui-arrow-right"></span>
            </button>
          </div>
          <div class="item">
            <p>A little bit further</p>
            <small>Be reachable <span style="font-size:30px;color:#2ECC71">:)</span></small>
            <input name='loc' placeholder="Location" class="form-input-text form-control flat" style="border-radius:0px" name='loc' type="text" required/>
            <button class="pull-left btn-inverse" style="height:40px;width:80px;font-size:25px" href="#PSet" data-slide="prev">
              <span class="fui-arrow-left"></span>
            </button>
            <button type="submit" name="SignUpComplete" class="pull-right btn-primary" style="height:40px;width:80px;font-size:25px">
              <span class="fui-check"></span>
            </button>
          </div>
       
        </div>
      </div>
    </form>
    </div>
  </center>
  <p>&nbsp;</p>
</div>
<?php endif;
if($status == 0): 
  #check username availability
 $GetUser = mysql_query("SELECT * FROM users WHERE username = '$usercheck' OR email = '$usercheck' ");
 $NumUser = mysql_num_rows($GetUser);
  #check handle availability
 $GetHandle = mysql_query("SELECT * FROM users WHERE nick = '$handle' ");
 $NumHand = mysql_num_rows($GetHandle);
  ?>
<form id='@signup_form' style="display:block" method="POST" action="signup_handler.php">
    <input value="<?php echo $_POST['nick'] ?>" type="text" id="nick" placeholder="Handle e.g Jamie"  name="nick" class="form-control flat" style="border-radius:0px;height:40px;width:85%;" autocomplete="off" required/>
      <i id="nick0" style="color:#E74C3C;display:none;margin-top:-30px;margin-right:5px" class="pull-right fui-cross-circle"></i>
      <i id="nick1" style="color:#2ECC71;display:none;margin-top:-30px;margin-right:5px" class="pull-right fui-check-circle"></i>
   <input value="<?php echo $_POST['email'] ?>" type="email" OnBlur="validate_email(email,'invalid mail');validate_form('signup_form')" placeholder="E-mail" id="Semail" name="email"  class="form-control flat" style="border-radius:0px;height:40px;width:85%;" autocomplete="off" required/>
       <i id="email0" style="color:#E74C3C;display:none;margin-top:-30px;margin-right:5px" class="pull-right fui-cross-circle"></i>
      <i id="email1" style="color:#2ECC71;display:none;margin-top:-30px;margin-right:5px" class="pull-right fui-check-circle"></i>
    <select class="form-control flat" style="border-radius:0px;height:40px;width:85%;" id="sex" name="sex"  required/>
      <optgroup label="Sex">
        <option value="MALE">Male</option>
        <option value="FEMALE">Female</option>
      </optgroup>
    </select>
    <tr><td><input OnBlur="validate_email(Semail,'invalid mail');PassMatch();"  type="password"  placeholder="Password" id="pass" name="pass"  class="form-control flat" style="border-radius:0px;height:40px;width:85%;" autocomplete="off" required/>
    <i id="pass0" style="color:#E74C3C;display:none;margin-top:-30px;margin-right:5px" class="pull-right fui-cross-circle"></i>
    <i id="pass0_ok" style="color:#2ECC71;display:none;margin-top:-30px;margin-right:5px" class="pull-right fui-check-circle"></i>
    <input OnBlur="validate_email(Semail,'invalid mail');PassMatch();" type="password"  placeholder="Re-type Password" id="pass2" name="pass2"  class="form-control flat" style="border-radius:0px;height:40px;width:85%;" autocomplete="off" required/>
    <i id="pass_2_0" style="color:#E74C3C;display:none;margin-top:-30px;margin-right:5px" class="pull-right fui-cross-circle"></i>
    <i id="pass_2_0_ok" style="color:#2ECC71;display:none;margin-top:-30px;margin-right:5px" class="pull-right fui-check-circle"></i>
    <small id="ErrorDiv" style="color:#FFF;display:none">User exist</small>
    <div style="width:85%;background-color:#FFF;text-align:left">
    <?php
      #error messages
      if ($_POST['pass'] != $_POST['pass2']) { echo '<div class="alert alert-danger" style="font-size:13px;border-radius:0px;border:0px">Passwords do not match</div>';   }
      if ($NumUser != NULL) { echo '<div class="alert alert-danger" style="font-size:13px;margin-top:-20px;border-radius:0px;border:0px">The email address has already been registered</div>';   }
      if ($NumHand != NULL) { echo '<div class="alert alert-danger" style="font-size:13px;margin-top:-20px;border-radius:0px;border:0px">The handle has been taken</div>';   }
      ?>
    </div>
      <button id="ButtonDisabled" OnClick="SubmitForm();"  class="btn-block btn-info hidden" data-toggle="collapse" style="height:40px;width:85%;">Verify</button>
      <button type="submit" name="SignUp" class="btn-block btn-info" style="height:40px;width:85%;">Sign Up</button>
    <p>&nbsp;</p>
    <span style="font-size:15px">Don't miss out on the fun</span>
    <button type="button" OnClick="window.self.location='index.php';" class="btn-block btn-primary" data-toggle="collapse" style="height:40px;width:85%;border-radius:20px;">Sign In</button>
</form>
<p>&nbsp;</p>
<p>&nbsp;</p>

<?php endif ?>
  </center>
</body>
</html>

    <script src="dist/js/vendor/jquery.min.js"></script>
    <script src="dist/js/vendor/video.js"></script>
    <script src="dist/js/flat-ui.min.js"></script>

    <script src="docs/assets/js/AjaxZing.js"></script>
    <script src="docs/assets/js/prettify.js"></script>
    <script src="docs/assets/js/application.js"></script>

<?php
  }
 ?>